import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons"; // Import the shopping cart icon

const Slider = (props) => {
  const [startIndex, setStartIndex] = useState(0);

  const imag = props.images;

  const handleNext = () => {
    if (startIndex >= 10) {
      setStartIndex(0);
    } else {
      setStartIndex(startIndex + 1);
    }
    console.log(startIndex);
  };

  const handlePrev = () => {
    if (startIndex <= -10) {
      setStartIndex(0);
    } else {
      setStartIndex(startIndex - 1);
    }
    console.log(startIndex);
  };

  return (
    <div>
      <div className="slider-container " style={{ display: "flex" }}>
        <div>
          <div
            class="card shadow-sm"
            style={{ width: "7rem", backgroundColor: "white", border: "0px" }}
          >
            <img
              src={imag[(startIndex + 10) % 10].image}
              //   alt={Image ${startIndex}}
              style={{ height: "100px", width: "100px", padding: "0px" }}
              className="card-img-top"
            />
            <div className="card-body" style={{ padding: "0.5rem" }}>
              <h5
                className="card-title fw-bold p-0 m-0"
                style={{ fontSize: "0.8rem" }}
              >
                Samsung Galaxy S24
              </h5>
              <p className="card-text fw-medium p-0 mt-1 m-0">$223</p>
              <div
                style={{ textDecoration: "none", color: "orange" }}
                className=""
              >
                ★★★
              </div>
              <div>
                <FontAwesomeIcon icon={faShoppingCart} />
              </div>
            </div>
          </div>
        </div>
        <div>
          <div
            class="card shadow-sm ms-3"
            style={{ width: "7rem", backgroundColor: "white", border: "0px" }}
          >
            <img
              src={imag[(startIndex + 1 + 10) % 10].image}
              //   alt={Image ${startIndex}}
              style={{ height: "100px", width: "100px", padding: "0px" }}
              className="card-img-top"
            />
            <div className="card-body" style={{ padding: "0.5rem" }}>
              <h5
                className="card-title fw-bold p-0 m-0"
                style={{ fontSize: "0.8rem" }}
              >
                Samsung Galaxy S24
              </h5>
              <p className="card-text fw-medium p-0 mt-1 m-0">$223</p>
              <div
                style={{ textDecoration: "none", color: "orange" }}
                className=""
              >
                ★★★
              </div>
              <div>
                <FontAwesomeIcon icon={faShoppingCart} />
              </div>
            </div>
          </div>
        </div>
        <div>
          <div
            class="card shadow-sm ms-3"
            style={{ width: "7rem", backgroundColor: "white", border: "0px" }}
          >
            <img
              src={imag[(startIndex + 2 + 10) % 10].image}
              //   alt={Image ${startIndex}}
              style={{ height: "100px", width: "100px", padding: "0px" }}
              className="card-img-top"
            />
            <div className="card-body" style={{ padding: "0.5rem" }}>
              <h5
                className="card-title fw-bold p-0 m-0"
                style={{ fontSize: "0.8rem" }}
              >
                Samsung Galaxy S24
              </h5>
              <p className="card-text fw-medium p-0 mt-1 m-0">$223</p>
              <div
                style={{ textDecoration: "none", color: "orange" }}
                className=""
              >
                ★★★
              </div>
              <div>
                <FontAwesomeIcon icon={faShoppingCart} />
              </div>
            </div>
          </div>
        </div>
        <div>
          <div
            class="card shadow-sm ms-3"
            style={{ width: "7rem", backgroundColor: "white", border: "0px" }}
          >
            <img
              src={imag[(startIndex + 3 + 10) % 10].image}
              //   alt={Image ${startIndex}}
              style={{ height: "100px", width: "100px", padding: "0px" }}
              className="card-img-top"
            />
            <div className="card-body" style={{ padding: "0.5rem" }}>
              <h5
                className="card-title fw-bold p-0 m-0"
                style={{ fontSize: "0.8rem" }}
              >
                Samsung Galaxy S24
              </h5>
              <p className="card-text fw-medium p-0 mt-1 m-0">$223</p>
              <div
                style={{ textDecoration: "none", color: "orange" }}
                className=""
              >
                ★★★
              </div>
              <div>
                <FontAwesomeIcon icon={faShoppingCart} />
              </div>
            </div>
          </div>
        </div>
        <div>
          <div
            class="card shadow-sm ms-3"
            style={{ width: "7rem", backgroundColor: "white", border: "0px" }}
          >
            <img
              src={imag[(startIndex + 4 + 10) % 10].image}
              //   alt={Image ${startIndex}}
              style={{ height: "100px", width: "100px", padding: "0px" }}
              className="card-img-top"
            />
            <div className="card-body" style={{ padding: "0.5rem" }}>
              <h5
                className="card-title fw-bold p-0 m-0"
                style={{ fontSize: "0.8rem" }}
              >
                Samsung Galaxy S24
              </h5>
              <p className="card-text fw-medium p-0 mt-1 m-0">$223</p>
              <div
                style={{ textDecoration: "none", color: "orange" }}
                className=""
              >
                ★★★
              </div>
              <div>
                <FontAwesomeIcon icon={faShoppingCart} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Slider;
