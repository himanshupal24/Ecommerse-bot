import { useEffect, useState } from "react";
import BarChart from "../components/BarChart";
import LineChart from "../components/LineChart";
import { collection, getDocs, query } from "firebase/firestore";
import { db } from "../firebase";

export default function AdminPanel() {
  const [graphData, setGraphData] = useState({});

  const getGraphData = (key, labelKey) => {
    return {
      labels: graphData[labelKey],
      datasets: [
        {
          label: "count",
          data: graphData[key],
          backgroundColor: "rgba(255, 99, 132, 0.2)",
        },
      ],
    };
  };

  useEffect(() => {
    const fetchDetails = async () => {
      const docSnap = await getDocs(query(collection(db, "analytics")));
      const data = docSnap.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
      setGraphData({
        labels: data.map((dta) => dta.id),
        viewsCount: data.map((dta) => dta.viewsCount),
        clickCount: data.map((dta) => dta.clickCount),
      });
    };
    fetchDetails();
  }, []);

  return (
    <div>
      <BarChart data={getGraphData("viewsCount", "labels")} />
      <LineChart data={getGraphData("clickCount", "labels")} />
    </div>
  );
}
